from kalkulator import Kalkulator

# Instance
Hitung = Kalkulator()