from Sepeda import Sepeda

# Define
Sepedaku = Sepeda()

# Instance
Sepedaku.menuSepeda()