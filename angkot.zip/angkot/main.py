from angkot import Angkot

# Instance
Angkot("Toyota", "Avanza", "Silver", 167, 8)